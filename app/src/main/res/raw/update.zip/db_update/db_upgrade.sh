/system/usr/bin/sqlite3 /system/usr/data/hojydb_mifi_config.sqlite "update device_config set value='V4260R03C01S99' where name='software';"
