#!/bin/sh

#DOWNLOAD_MODE="/sys/module/restart/parameters/download_mode"
DOWNLOAD_MODE="/sys/module/msm_poweroff/parameters/download_mode"

if [ -f "/etc/log_switch" ]; then
	echo `cat /etc/log_switch` > $DOWNLOAD_MODE
	echo "set_download_mode to DOWNLOAD_MODE"
else
	echo 0 > $DOWNLOAD_MODE
	echo "set_download_mode to 0" 
fi

MS_WEB_FUNC_SHOW_FILE="/usr/mifi/hwebserver/func_show_list.xml"
MS_WEB_SKIN_SHOW_FILE="/usr/mifi/hwebserver/system.config"
MS_BACKUP_WEB_FUNC_SHOW_FILE="/misc/func_show_list.xml"
MS_BACKUP_WEB_SKIN_SHOW_FILE="/misc/system.config"

if [[ ! -s $MS_WEB_FUNC_SHOW_FILE && -s $MS_BACKUP_WEB_FUNC_SHOW_FILE ]]; then
	cp $MS_BACKUP_WEB_FUNC_SHOW_FILE $MS_WEB_FUNC_SHOW_FILE
	chmod 755 $MS_WEB_FUNC_SHOW_FILE
fi
if [[ ! -s $MS_WEB_SKIN_SHOW_FILE && -s $MS_BACKUP_WEB_SKIN_SHOW_FILE ]]; then
	cp $MS_BACKUP_WEB_SKIN_SHOW_FILE $MS_WEB_SKIN_SHOW_FILE
	chmod 755 $MS_WEB_SKIN_SHOW_FILE	
fi


#mv /usr/bin/time_daemon  /usr/bin/time_daemon_bak

cd /usr/mifi

./restart_upgrade &

if [ `cat /proc/hw_version` -neq 24 ]; then
	./restart_uc_gui &
fi

#./restart_lend_manager &

cd /usr/sbin
chmod +x performance_tuning.sh
./performance_tuning.sh &

cd /usr/mifi/hwebserver
./restart_hwebserver &

echo 2 > /proc/sys/vm/panic_on_oom
echo 4096 > /proc/sys/vm/min_free_kbytes

count=0
while [ $count -lt 10 ]
do
    if [ -e /proc/sys/net/ipv4/ip_forward ]
    then
        echo 1 > /proc/sys/net/ipv4/ip_forward
        break
    fi
    sleep 1
    count=$(($count + 1))
done

sleep 5
/usr/bin/tr_snmp_config.sh &
#/usr/bin/tr-agent -d /usr/bin/conf &
#/usr/mifi/restart_redirect_manager &


#/usr/mifi/restart_dnsmasq_record &
if [ `cat /proc/hw_version` -eq 24 ]; then
    gps &
    #wangjb add for wakeup ap test
    #/usr/sbin/check_and_wakeup_android.sh &
    echo 0 > /sys/class/leds/hwake/brightness
    /usr/mifi/check_netdata &
fi

