#!/bin/sh

last_time=`cat /proc/uptime |cut -d"." -f1`
currn_time=`cat /proc/uptime |cut -d"." -f1`

interval_time=1

while [ 1 -eq 1 ]
do
    echo "check_andriod_lock" > /sys/power/wake_lock
	
    currn_time=`cat /proc/uptime |cut -d"." -f1`
    if [ $currn_time -gt $(($last_time + 2)) ]
    then
        echo ========== enter wakeup android =========
        echo 0 > /sys/class/leds/hwake/brightness
        sleep 1
        echo 1 > /sys/class/leds/hwake/brightness
        last_time=$(($currn_time+1))
    else
        last_time=$currn_time
    fi

    echo "check_andriod_lock" > /sys/power/wake_unlock

    sleep $interval_time
done

