echo performance > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
if [ `cat /proc/hw_version` -eq 26 ]; then
	cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq >  /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq
fi



echo 1048576 > /proc/sys/net/core/rmem_default
echo 1048576 > /proc/sys/net/core/rmem_max
echo 1048576 > /proc/sys/net/core/wmem_default
echo 1048576 > /proc/sys/net/core/wmem_max
echo 0 > /proc/sys/net/ipv4/tcp_timestamps 
echo 1 > /proc/sys/net/ipv4/tcp_sack 
echo 1 > /proc/sys/net/ipv4/tcp_window_scaling

mount -t debugfs  debugfs  /sys/kernel/debug
echo 0x0> /sys/kernel/debug/ieee80211/phy0/ath6kl/fwlog_mask